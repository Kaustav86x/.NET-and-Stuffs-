﻿namespace RailwayManagementSystem.Models.ViewModels
{
    public class GetTrainsByDestination
    {
        public string? Source { get; set; }
        public string? Destination { get; set; }
    }
}
