﻿namespace RailwayManagementSystem.Models.ViewModels
{
        public class ViewUser // child
        {
            public string? Id { get; set; }
            public string? Fname { get; set; }
            public string? Lname { get; set; }
            public long Phone { get; set; }
            public string? Email { get; set; }
            public string? Role { get; set; } 
        }
 }
