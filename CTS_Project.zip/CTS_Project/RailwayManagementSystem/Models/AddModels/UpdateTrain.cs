﻿namespace RailwayManagementSystem.Models.AddModels
{
    public class UpdateTrain
    {
    }
}
