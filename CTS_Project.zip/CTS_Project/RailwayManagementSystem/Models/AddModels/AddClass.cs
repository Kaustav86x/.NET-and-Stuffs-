﻿namespace RailwayManagementSystem.Models.AddModels
{
    public class AddClass
    {
        public string Class_type { get; set; }
        public int Fare { get; set; }
        public int SeatCapacity { get; set; }
    }
}
