﻿namespace RailwayManagementSystem.Models.AddModels
{
    public class UpdateTicketDetails
    {
        public string Passenger { get; set; }
        public string Class_Type { get; set; }
        public string SeatNo { get; set; }
    }
}
