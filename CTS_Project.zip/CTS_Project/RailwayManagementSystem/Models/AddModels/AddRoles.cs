﻿namespace RailwayManagementSystem.Models.AddModels
{
    public class AddRoles
    {
        public string Id { get; set; }
        public string Role_type { get; set; }
    }
}
