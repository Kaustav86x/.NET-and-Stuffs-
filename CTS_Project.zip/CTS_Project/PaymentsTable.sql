﻿insert into Payments values(NEWID(), '2023-05-12', 'MASTERCARD', 'Not yet confirmed', 1, 'R2');
